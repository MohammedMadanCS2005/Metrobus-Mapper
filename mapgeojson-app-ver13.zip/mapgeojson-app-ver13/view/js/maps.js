var map = L.map('map').setView([47.560539, -52.712830], 13);
var baseMap = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png?{foo}', { foo: 'bar', attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' });

var baseMaps = {
    "OpenStreetMap": baseMap
};

baseMap.addTo(map);

$("#btn-clear").click(function(event) {
    map.eachLayer(function(layer) {
        map.removeLayer(layer);
    });
    baseMap.addTo(map);
});

$("#btn-route1").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/1',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/1',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});



$("#btn-route2").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/2',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/2',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route3").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/3',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/3',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route5").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/5',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/5',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route6").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/6',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/6',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route9").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/9',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/9',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route10").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/10',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/10',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route11").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/11',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/11',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route12").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/12',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/12',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route14").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/14',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/14',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route15").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/15',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/15',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route16").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/16',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/16',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route18").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/18',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/18',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route19").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/19',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/19',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route20").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/20',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/20',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route21").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/21',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/21',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});
$("#btn-route22").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/22',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/22',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route23").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/23',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/23',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route30").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/30',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/30',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});