const Location = require("../models/map")

async function get_collection(db) {
    return await db.collection('locations');
}

const create = async(req, res) => {
    const new_locations = new Location(req.body.id, req.body.stopid, req.body.stopname, req.body.stoplat, req.body.stoplon);
    let db = req.db;
    let collection = await get_collection(db);
    new_locations.save(collection).then(obj => {
        res.send(obj);
    }).catch(obj => {
        res.send(obj);
    })
}

const deleteOne = async(req, res) => {
    let delete_id = req.params.id;
    let db = req.db;
    let collection = await get_collection(db);
    Location.delete(collection, delete_id)
        .then(obj => {
            res.send(obj);
        })
        .catch(err => {
            res.send(err);
        });
}

module.exports = {
    create,
    deleteOne
}