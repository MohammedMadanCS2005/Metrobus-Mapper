const Location = require("../models/map")
var fs = require('fs');
//two collections one for bus stops (points) and the other for routes (linestring)
async function get_collection(db) {
    return await db.collection('busstops');
}

async function get_collectionroutes(db) {
    return await db.collection('routes');
}

const createbustops = async(req, res) => {
    //read stops data form geojson
    let rawdata = fs.readFileSync('metrobus_stops.geojson');
    let par = JSON.parse(rawdata);

    for (let index = 0; index < par.features.length; index++) {

        const properties = par.features[index].properties;
        const geometry = par.features[index].geometry;



        const new_locations = new Location(index, properties, geometry);
        let db = req.db;
        let collection = await get_collection(db);
        new_locations.savebusstops(collection);

    }


    res.send('All Data is added');
}

const createroutes = async(req, res) => {
    let rawdataroutes = fs.readFileSync('metrobus_routes.geojson');
    let routes = JSON.parse(rawdataroutes);

    for (let index = 0; index < routes.features.length; index++) {

        const propertiesroutes = routes.features[index].properties;
        const geometryroutes = routes.features[index].geometry;



        const new_routes = new Location(index, propertiesroutes, geometryroutes);
        let db = req.db;
        let collection = await get_collectionroutes(db);
        new_routes.savebusroutes(collection);
    }
    res.send('All Routes is added');
}


const getbusstop = async(req, res) => {
    const id = req.params.id;
    let db = req.db;
    let collection = await get_collection(db);
    try {
        let obj = await Location.getstopById(collection, id);
        res.send(obj);
    } catch (err) {
        res.send('There was an error while retrieving your Stop. (err:' + err + ')');
        throw new Error(err);
    }
}

const getbusroutes = async(req, res) => {
    const route_to_get = req.params.id;
    let db = req.db;
    let collection = await get_collectionroutes(db);
    try {
        let obj = await Location.getrouteById(collection, route_to_get);
        res.send(obj);
    } catch (err) {
        res.send('There was an error while retrieving the route data. (err:' + err + ')');
        throw new Error(err);
    }
}



module.exports = {
    createbustops,
    createroutes,
    getbusstop,
    getbusroutes
}