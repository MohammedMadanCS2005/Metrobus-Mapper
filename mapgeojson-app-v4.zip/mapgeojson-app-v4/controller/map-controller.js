const Location = require("../models/map")
var fs = require('fs');
//two collections one for bus stops (points) and the other for routes (linestring)
async function get_collection(db) {
    return await db.collection('busstops');
}

async function get_collectionroutes(db) {
    return await db.collection('routes');
}
//createbustops adds the bus stops points into the database
const createbustops = async(req, res) => {
        //read stops data form geojson
        let rawdata = fs.readFileSync('metrobus_stops.geojson');
        let par = JSON.parse(rawdata);

        for (let index = 0; index < par.features.length; index++) {
            //loops and separates each feature into two parts the properties of the stops and the geometry
            const properties = par.features[index].properties;
            const geometry = par.features[index].geometry;



            const new_locations = new Location(index, properties, geometry);
            let db = req.db;
            let collection = await get_collection(db);
            new_locations.savebusstops(collection);

        }


        res.send('All Data is added');
    }
    //createroutes adds the routes data into the database
const createroutes = async(req, res) => {
    //read route data form geojson
    let rawdataroutes = fs.readFileSync('metrobus_routes.geojson');
    let routes = JSON.parse(rawdataroutes);

    for (let index = 0; index < routes.features.length; index++) {
        //loops and separates each feature into two parts the properties of the route and the geometry
        const propertiesroutes = routes.features[index].properties;
        const geometryroutes = routes.features[index].geometry;



        const new_routes = new Location(index, propertiesroutes, geometryroutes);
        let db = req.db;
        let collection = await get_collectionroutes(db);
        new_routes.savebusroutes(collection);
    }
    res.send('All Routes is added');
}

//gets the bus stop data using an id
const getbusstop = async(req, res) => {
        const id = req.params.id;
        let db = req.db;
        let collection = await get_collection(db);
        try {
            let obj = await Location.getstopById(collection, id);
            res.send(obj);
        } catch (err) {
            res.send('There was an error while retrieving your Stop. (err:' + err + ')');
            throw new Error(err);
        }
    }
    //gets the route data using an id
const getbusroutes = async(req, res) => {
    const route_to_get = req.params.id;
    let db = req.db;
    let collection = await get_collectionroutes(db);
    try {
        let obj = await Location.getrouteById(collection, route_to_get);
        res.send(obj);
    } catch (err) {
        res.send('There was an error while retrieving the route data. (err:' + err + ')');
        throw new Error(err);
    }
}



module.exports = {
    createbustops,
    createroutes,
    getbusstop,
    getbusroutes
}