const Validator = require("validatorjs")
class Location {
    constructor(id, stopid, stopname, stoplat, stoplon) {
        this._id = id;
        this.stopid = stopid;
        this.stopname = stopname;
        this.stoplat = stoplat;
        this.stoplon = stoplon;
    }

    isValid() {
        const rules = {
            stopid: 'required|integer',
            stopname: 'required|string',
            stoplat: 'required|string',
            stoplon: 'required|string'

        }
        const validation = new Validator(this, rules);
        return validation.passes();
    };

    save(collection) {
        let loc = this;
        return new Promise((resolve, reject) => {
            collection.insertOne(loc, (err, obj) => {
                if (err) reject(err);
                console.log('A location was inserted in the database with id -> ' + obj.insertedId);
                resolve({ msg: 'The location was successfully saved in the database' })
            });
        });

    };

    static delete(collection, id) {
        let loc_id = id;
        return new Promise((resolve, reject) => {
            collection.deleteOne({ _id: parseInt(loc_id) }, (err, obj) => {
                if (err) reject(err);
                console.log('The Location with id = ' + loc_id + ' was correctly deleted');
                resolve({ msg: "The Location was correctly deleted" })
            });
        });
    };

    static async getLocationById(collection, id) {
        var id_get = id;
        return new Promise(async function(resolve, reject) {
            collection.findOne({}, { "_id": parseInt(id_get) }, (err, obj) => {
                if (err) reject(err);
                console.log('The Location with id = ' + JSON.stringify(obj) + '');
                resolve({ msg: "The Location was found" })
            });
        });
    };

    static async update(collection, id, stopid, stopname, stoplat, stoplon) {
        let updateBook = {
            stopid: stopid,
            stopname: stopname,
            stoplat: stoplat,
            stoplon: stoplon
        }
        return new Promise(async(resolve, reject) => {
            collection.updateOne({ "_id": parseInt(id) }, { $set: updateBook }, (err, obj) => {
                if (err) reject(err);
                console.log('The Location updated');
                resolve({ msg: "The Location was updated" })
            });
        });
    };

}

module.exports = Location;