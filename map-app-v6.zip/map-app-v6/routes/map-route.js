const express = require('express')
const router = express.Router()
const map_controller = require("../controller/map-controller")

router.post("/", map_controller.insertone)
router.get("/", map_controller.create)
router.delete("/:id", map_controller.deleteOne)
router.get("/:id", map_controller.getOne)
router.put('/:id', map_controller.updateOne)

module.exports = router