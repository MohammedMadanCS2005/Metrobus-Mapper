var request = require('request');
var myurl = 'http://localhost:3000';

let stop1 = {
    id: 1,
    stopid: 1000,
    stopname: 'VILLAGE MALL',
    stoplat: 47.533785,
    stoplon: -52.750122
}

request.post({
    headers: { 'content-type': 'application/json' },
    url: myurl + '/maps',
    body: JSON.stringify(stop1)
}, function(error, response, body) {
    if (error) console.log(error);
    console.log(body);
});

/* request.delete({
    headers: { 'content-type': 'application/json' },
    url: myurl + '/maps/1',
}, function(error, response, body) {
    if (error) console.log(error);
    console.log(body);
}) */