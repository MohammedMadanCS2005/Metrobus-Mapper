var request = require('request');
var myurl = 'http://localhost:3000';



request.get({
    headers: { 'content-type': 'application/json' },
    url: myurl + '/mapsroutes/23',
}, function(error, response, body) {
    if (error) console.log(error);
    console.log(body);
});