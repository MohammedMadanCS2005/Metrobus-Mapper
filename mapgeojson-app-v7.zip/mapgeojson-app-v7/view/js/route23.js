$(document).ready(function() {
    var map = L.map('map').setView([47.560539, -52.712830], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png?{foo}', { foo: 'bar', attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' }).addTo(map);

    $("#btn-route23").click(function(event) {
        event.preventDefault();
        $.ajax({
            url: '/mapsroutes/23',
            type: 'GET',
            contentType: 'application/json',
            success: function(response) {
                for (var i = 0; i < response.maps.length; i++) {
                    var linestring = response.maps[i].geometry;
                    linestring

                }


            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText
                alert('Error - ' + errorMessage);
            }
        });
    });


});