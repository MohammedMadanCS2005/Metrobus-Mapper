var map = L.map('map').setView([47.560539, -52.712830], 13);
var baseMap = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png?{foo}', { foo: 'bar', attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' });

var baseMaps = {
    "OpenStreetMap": baseMap
};

baseMap.addTo(map);

$("#btn-clear").click(function(event) {
    map.eachLayer(function(layer) {
        map.removeLayer(layer);
    });
    baseMap.addTo(map);
});

$("#btn-route1").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/1',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/1',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "1") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});



$("#btn-route2").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/2',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/2',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "2") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route3").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/3',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/3',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "3") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route5").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/5',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/5',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "5") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route6").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/6',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/6',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "6") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route9").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/9',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/9',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "9") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route10").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/10',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/10',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "10") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route11").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/11',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/11',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "11") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route12").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/12',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/12',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "12") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route14").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/14',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/14',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "14") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route15").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/15',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/15',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "15") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route16").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/16',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/16',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "16") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route18").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/18',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/18',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "18") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route19").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/19',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/19',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "19") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route20").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/20',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/20',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "20") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route21").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/21',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/21',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "21") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});
$("#btn-route22").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/22',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/22',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "22") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route23").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/23',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/23',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "23") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route30").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/30',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/30',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        let btnDiv = document.createElement('div')

                        let msg = document.createElement('h3');
                        msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


                        let btnschedule = document.createElement('button');
                        btnschedule.innerHTML = "Schedule";
                        btnschedule.className = 'btnpopup';

                        var id_input = response.maps[i].properties.stop_id;

                        btnschedule.onclick = async() => {
                            $(".showfares").hide();
                            $(".listtimes").show();
                            $("#list-times").empty();
                            let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                            $("#list-times").append(tbl);
                            $.ajax({
                                url: '/mapsstoptime/' + id_input,
                                type: 'GET',
                                contentType: 'application/json',
                                success: function(response) {
                                    for (let i = 0; i < response.times.length; i++) {
                                        let obj = response.times[i];
                                        let tbl_line = '';
                                        /**  To add an effect in the table, we can apply
                                             even and odd classes. */
                                        if (obj.route_id == "30") {
                                            if (i % 2 == 0) {
                                                tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            } else {
                                                tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                            }
                                            $("#table-list").append(tbl_line)
                                        }
                                    }
                                },
                                error: function(xhr, status, error) {
                                    var errorMessage = xhr.status + ': ' + xhr.statusText
                                    alert('Error - ' + errorMessage);
                                }
                            });

                        }

                        btnDiv.append(msg)
                        btnDiv.append(btnschedule)
                        layer.bindPopup(btnDiv)
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});