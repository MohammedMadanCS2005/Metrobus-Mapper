$(document).ready(function() {

    $("#btn-showfares").click(function(event) {
        event.preventDefault();
        $(".listtimes").hide();
        $(".showfares").show();

    });


});