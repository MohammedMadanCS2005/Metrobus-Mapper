$(document).ready(function() {

    $("#btn-addstoptime").click(function(event) {
        alert("There is a lot of data to be processed. It takes time. Please be patient!")
        event.preventDefault();
        $.ajax({
            url: '/mapsstoptime',
            type: 'POST',
            contentType: 'application/json',
            success: function(response) {

                console.log(JSON.stringify(response));
                $("#add-out").text(response);
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText
                alert('Error - ' + errorMessage);
            }
        });
    });


});