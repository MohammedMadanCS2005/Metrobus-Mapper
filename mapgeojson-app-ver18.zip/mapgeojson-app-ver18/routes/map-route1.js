const express = require('express')
const router = express.Router()
const map_controller = require("../controller/map-controller")

router.post("/", map_controller.createroutes)
router.get("/:id", map_controller.getbusroutes)

module.exports = router