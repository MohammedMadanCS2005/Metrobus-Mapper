const { count } = require('console');
const { SSL_OP_SSLEAY_080_CLIENT_DH_BUG } = require('constants');
const fs = require('fs');
const Location = require("../models/map")

async function get_collection(db) {
    return await db.collection('locations');
}

const create = async(req, res) => {
    let db = req.db;
    let collection = await get_collection(db);
    let count = 0;

    let array = fs.readFileSync('data.txt', 'utf8').split('\n');

    console.log('Start')
    for (let index = 1; index < array.length - 1; index++) {

        let splitarray = array[index].split(',');
        let stopid = splitarray[0];
        let stopname = splitarray[2];
        let stoplat = splitarray[4];
        let stoplon = splitarray[5];
        const new_locations = new Location(parseInt(count), parseInt(stopid), stopname, stoplat, stoplon);


        new_locations.save(collection);
        count = count + 1;
    }
    res.send('All data is added');
}

const insertone = async(req, res) => {
    const a_location = new Location(parseInt(req.body.id), parseInt(req.body.stopid), req.body.stopname, req.body.stoplat, req.body.stoplon);
    let db = req.db;
    let collection = await get_collection(db);
    a_location.save(collection).then(obj => {
        res.send(obj);
    }).catch(obj => {
        res.send(obj);
    })
}

const deleteOne = async(req, res) => {
    let delete_id = req.params.id;
    let db = req.db;
    let collection = await get_collection(db);
    Location.delete(collection, delete_id)
        .then(obj => {
            res.send(obj);
        })
        .catch(err => {
            res.send(err);
        });
}

module.exports = {
    create,
    deleteOne,
    insertone
}