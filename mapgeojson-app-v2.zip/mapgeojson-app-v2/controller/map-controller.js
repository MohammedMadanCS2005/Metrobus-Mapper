const Location = require("../models/map")
var fs = require('fs');

async function get_collection(db) {
    return await db.collection('busstops');
}

async function get_collectionroutes(db) {
    return await db.collection('routes');
}

const create = async(req, res) => {
    let rawdata = fs.readFileSync('metrobus_stops.geojson');
    let par = JSON.parse(rawdata);

    for (let index = 0; index < par.features.length; index++) {

        const properties = par.features[index].properties;
        const geometry = par.features[index].geometry;



        const new_locations = new Location(index, properties, geometry);
        let db = req.db;
        let collection = await get_collection(db);
        new_locations.save(collection);
    }


    let rawdataroutes = fs.readFileSync('metrobus_routes.geojson');
    let routes = JSON.parse(rawdataroutes);

    for (let index = 0; index < routes.features.length; index++) {

        const propertiesroutes = routes.features[index].properties;
        const geometryroutes = routes.features[index].geometry;



        const new_routes = new Location(index, propertiesroutes, geometryroutes);
        let db = req.db;
        let collection = await get_collectionroutes(db);
        new_routes.save(collection);
    }



    res.send('All Data is added');
}



module.exports = {
    create
}