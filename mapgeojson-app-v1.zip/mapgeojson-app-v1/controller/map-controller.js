const Location = require("../models/map")
var fs = require('fs');

async function get_collection(db) {
    return await db.collection('busstops');
}

const create = async(req, res) => {
    let rawdata = fs.readFileSync('metrobus_stops.geojson');
    let par = JSON.parse(rawdata);

    for (let index = 0; index < par.features.length; index++) {

        const properties = par.features[index].properties;
        const geometry = par.features[index].geometry;



        const new_locations = new Location(index, properties, geometry);
        let db = req.db;
        let collection = await get_collection(db);
        new_locations.save(collection);
    }
    res.send('All Bus Stops are added');
}



module.exports = {
    create
}