class Location {
    constructor(id, properties, geometry) {
        this._id = id;
        this.properties = properties;
        this.geometry = geometry;

    }

    save(collection) {
        let loc = this;
        return new Promise((resolve, reject) => {
            collection.insertOne(loc, (err, obj) => {
                if (err) reject(err);
                console.log('A Bus Stop was inserted in the database with id -> ' + obj.insertedId);
                resolve({ msg: 'The Bus Stop was successfully saved in the database' })
            });
        });

    }

}

module.exports = Location;