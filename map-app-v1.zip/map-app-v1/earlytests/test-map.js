const Location = require('../models/map')
const MongoClient = require("mongodb").MongoClient
const uri = "mongodb://localhost:27017";
const client = new MongoClient(uri, { useUnifiedTopology: true });

async function get_collection() {
    try {
        await client.connect();
        let db = client.db('mapped');
        return await db.collection('locations');
    } catch (err) {
        console.log(err);
    }
}

async function run() {
    let p = new Location(1, 12, "A", 32, 33);
    var col = await get_collection();

    p.save(col).then(obj => {
        console.log(obj)
    }).catch(obj => {
        console.log(obj)
    });
}
run();