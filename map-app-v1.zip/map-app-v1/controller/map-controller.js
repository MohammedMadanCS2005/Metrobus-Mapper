const Location = require("../models/map")

async function get_collection(db) {
    return await db.collection('locations');
}

const create = async(req, res) => {
    const new_locations = new Location(parseInt(req.body.id), req.body.stopid, req.body.stopname, req.body.stoplat, req.body.stoplon);
    let db = req.db;
    let collection = await get_collection(db);
    new_locations.save(collection).then(obj => {
        res.send(obj);
    }).catch(obj => {
        res.send(obj);
    })
}

module.exports = { create }