class Location {
    constructor(id, stopid, stopname, stoplat, stoplon) {
        this.id = id;
        this.stopid = stopid;
        this.stopname = stopname;
        this.stoplat = stoplat;
        this.stoplon = stoplon;
    }

    save(collection) {
        let loc = this;
        return new Promise((resolve, reject) => {
            collection.insertOne(loc, (err, obj) => {
                if (err) reject(err);
                console.log('A location was inserted in the database with id -> ' + obj.insertedId);
                resolve({ msg: 'The location was successfully saved in the database' })
            });
        });

    }
}

module.exports = Location;