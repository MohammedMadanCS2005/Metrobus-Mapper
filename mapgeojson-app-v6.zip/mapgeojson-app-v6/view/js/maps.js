var map = L.map('map').setView([47.560539, -52.712830], 13);
var baseMap = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png?{foo}', { foo: 'bar', attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' });


var baseMaps = {
    "OpenStreetMap": baseMap
};

var layerControl = L.control.layers(baseMaps, {}).addTo(map);
baseMap.addTo(map);

var roads;
var roadsLayer;

var roadsLayer;
var styleRoads = function() {
    return {
        weight: 5,
        opacity: 1,
        color: '#FFA500',
        fillOpacity: 0.7
    }
}

$.getJSON("./metrobus_routes.geojson", function(data) {
    roads = data;
    roadsLayer = L.geoJson(data, {
        onEachFeature: function(feature, layer) {
            layer.bindPopup('<h3>' + feature.properties.route_long_name + " - " + feature.properties.route_id + '</h3>');
        },
        style: styleRoads
    });
    layerControl.addOverlay(roadsLayer, 'Routes');
});


$.getJSON("./metrobus_stops.geojson", function(data) {
    Busstops = data;
    BusstopsLayer = L.geoJson(data, {
        onEachFeature: function(feature, layer) {
            layer.bindPopup('<h3>' + feature.properties.stop_name + " - " + feature.properties.stop_id + '</h3>');
        },
        pointToLayer: function(feature, latlng) {
            var librarySVG = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" style="" xml:space="preserve" width="120.87" height="122.88"><rect id="backgroundrect" width="100%" height="100%" x="0" y="0" fill="none" stroke="none"/><g class="currentLayer" style=""><title>Layer 1</title><g id="svg_1" class="selected" fill="#1a1aeb" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3"><path d="M79.21,70.64c11.61,1.57,21.65,4.57,28.79,8.49c8.11,4.45,12.88,10.3,12.88,17c0,8.29-7.44,15.35-19.46,20.05 c-10.58,4.14-25.07,6.69-40.98,6.69c-15.9,0-30.4-2.56-40.98-6.69C7.44,111.49,0,104.43,0,96.14c0-6.8,4.91-12.71,13.23-17.19 c7.32-3.94,17.6-6.93,29.47-8.44l1.28,10.11c-10.6,1.34-19.64,3.94-25.92,7.32c-4.93,2.65-7.83,5.51-7.83,8.2 c0,3.65,4.95,7.41,12.95,10.53c9.44,3.69,22.61,5.97,37.26,5.97c14.65,0,27.82-2.28,37.26-5.97c8-3.13,12.95-6.89,12.95-10.53 c0-2.63-2.8-5.44-7.57-8.05c-6.09-3.34-14.88-5.94-25.23-7.34L79.21,70.64L79.21,70.64z M65.33,44.36v50.87H55.1V44.36 c-9.95-2.32-17.36-11.24-17.36-21.89C37.74,10.06,47.8,0,60.22,0c12.41,0,22.47,10.06,22.47,22.47 C82.69,33.13,75.28,42.05,65.33,44.36L65.33,44.36z" id="svg_2" fill="#1a1aeb" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3"/></g></g></svg>';
            var iconUrlLibrary = 'data:image/svg+xml;base64,' + btoa(librarySVG);
            var iconLibrary = L.icon({
                iconUrl: iconUrlLibrary,
                iconSize: [27, 27],
                iconAnchor: [13, 27],
            });
            return L.marker(latlng, { icon: iconLibrary });
        },
    });
    layerControl.addOverlay(BusstopsLayer, 'Busstops');
});