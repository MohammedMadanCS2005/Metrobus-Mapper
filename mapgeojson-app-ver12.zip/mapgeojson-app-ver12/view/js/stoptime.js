$(document).ready(function() {

    $("#btn-find-times").click(function(event) {
        event.preventDefault();
        $("#list-times").empty();

        let id_input = $("#find-times-inp").val();
        let tbl = '<table id="table-list"><tr><th>Stop Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
        $("#list-times").append(tbl);

        $.ajax({
            url: '/mapsstoptime/' + id_input,
            type: 'GET',
            contentType: 'application/json',
            success: function(response) {
                for (let i = 0; i < response.times.length; i++) {
                    let obj = response.times[i];
                    let tbl_line = '';
                    /**  To add an effect in the table, we can apply
                         even and odd classes. */
                    if (i % 2 == 0) {
                        tbl_line = '<tr class="even-row"><td>' + obj.stop_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                    } else {
                        tbl_line = '<tr class="odd-row"><td>' + obj.stop_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                    }
                    $("#table-list").append(tbl_line)
                }
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText
                alert('Error - ' + errorMessage);
            }
        });
    });


});