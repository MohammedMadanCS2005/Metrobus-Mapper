const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.json()); // support json encoded bodies

const contacts = require('./controller/contacts');// Here we import our code with the contacts operations
const mongo = require('./utils/db.js');
var server;

async function loadDBClient() {
  await mongo.connectToDB();
};  
loadDBClient();

// contacts resource paths
app.get('/contacts', contacts.list_all);
app.get('/contacts/:name', contacts.get_contact);
app.post('/contacts', contacts.add);
app.put('/contacts/:name', contacts.update_contact);
app.delete('/contacts/:name', contacts.delete_contact);

server = app.listen(port, () => {
  console.log('Example app listening at http://localhost:%d', port);
});


process.on('SIGINT', () => {
  console.info('SIGINT signal received.');
  console.log('Closing Mongo Client.');
  mongo.closeDBConnection();
  server.close(() => {
    console.log('Http server closed.');
  });
});
