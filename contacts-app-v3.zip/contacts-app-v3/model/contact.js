/**
 * The class contact, with a main constructor and two methods
 * to add more fields retrieved with the third-party APIs
 */

class Contact {
    constructor(name, email, tel, address){
        this.name = name;
        this.email = email;
        this.tel = tel;
        this.address = address;
    }

    addGeoCoordinates(lat, lng, provider){
        this.lat = lat;
        this.lng = lng;
        this.provider = provider;
    }

    addWeatherData(temperature, feels_like, humidity){
        this.temperature = temperature;
        this.feels_like = feels_like;
        this.humidity = humidity;
    }
}

module.exports.Contact = Contact;