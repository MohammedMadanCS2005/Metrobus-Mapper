const request = require('request');
var myurl = 'http://localhost:3000';

// Now let's update the contact information for Amilcar Soares
var data4 = {
    name: 'Amilcar Soares', 
    email: 'amilcarsj@mun.ca', 
    tel: '709-221-4567', 
    address: 'My new address at St. Johns updated'
};

request.put({
    headers: {'content-type': 'application/json'},
    url:     myurl+'/contacts/Amilcar Soares',
    body:    JSON.stringify(data4)
}, function(error, response, body){
    console.log('-------- Updating contact by name. --------');
    console.log(body);
});

// Finally, let's delete the contact info of Bob Churchil
request.delete({
    headers: {'content-type': 'application/json'},
    url:     myurl+'/contacts/Bob Churchil'
}, function(error, response, body){
    console.log('-------- Deleting contact by name. --------');
    console.log(body);
});