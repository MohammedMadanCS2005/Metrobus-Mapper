const request = require('request');
var myurl = 'http://localhost:3000';

// Adding a new user
var data1 = {
    name: 'Amilcar Soares', 
    email: 'amilcarsj@mun.ca', 
    tel: '709-456-7891', 
    address: '230 Elizabeth Ave, St. John\'s, Newfoundland'
};

request.post({
        headers: {'content-type': 'application/json'},
        url:     myurl+'/contacts',
        body:    JSON.stringify(data1)        
    }, function(error, response, body){
        console.log(body);
});

// Adding another user
var data2 = {
    name: 'John Smith', 
    email: 'jsmith@mun.ca', 
    tel: '709-456-7891', 
    address: '235 Forest Road, St. John\'s, Newfoundland'
};

request.post({
        headers: {'content-type': 'application/json'},
        url:     myurl+'/contacts',
        body:    JSON.stringify(data2)        
    }, function(error, response, body){
        console.log(body);
});

// Adding another one
var data3 = {
    name: 'Bob Churchil', 
    email: 'bchurchil@mun.ca', 
    tel: '709-987-6543', 
    address: '50 Crosbie Road, St. John\'s, Newfoundland'
};

request.post({
        headers: {'content-type': 'application/json'},
        url:     myurl+'/contacts',
        body:    JSON.stringify(data3)        
    }, function(error, response, body){
        console.log(body);
});

