const request = require('request');
var myurl = 'http://localhost:3000';

// Retrieving the list of all contacts.
// It should retrieve the three we just have added.
request.get({
    headers: {'content-type': 'application/json'},
    url:     myurl+'/contacts',
}, function(error, response, body){
    console.log('-------- Listing all contacts. --------');
    console.log(body);
});

// Retrieving the contact info for Amilcar Soares
request.get({
    headers: {'content-type': 'application/json'},
    url:     myurl+'/contacts/Amilcar Soares',
}, function(error, response, body){
    console.log('-------- Listing contact info. --------');
    console.log(body);
});

// // Retrieving the contact info of a contact that is not in
// // contacts list. It should output a message that the contact
// // was not found. 
request.get({
    headers: {'content-type': 'application/json'},
    url:     myurl+'/contacts/Someone Unknown',
}, function(error, response, body){
    console.log('-------- Listing contact info. --------');
    console.log(body);
});
