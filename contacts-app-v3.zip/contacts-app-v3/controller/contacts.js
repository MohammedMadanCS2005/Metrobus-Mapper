const fs = require('fs');
const file_name = 'contacts_list.txt';
const v = require('../utils/validate-fields');
const get_geo = require('../utils/get-geo-data');
const get_weather = require('../utils/get-weather-data');

const client = require('../utils/db.js');
const Contact = require('../model/contact').Contact;


async function _get_contacts_collection (){
    let db = await client.getDb();
    return await db.collection('contacts');
};

/**
 * A function that adds a contact to the database.
 * @param {*} req 
 * @param {*} res 
 */

module.exports.add = async (req, res) => {
    let name = req.body.name;
    let email = req.body.email;
    let tel = req.body.tel; 
    let address = req.body.address;
    let isValid = await v.validate_fields(name, email, tel, address);
    if (isValid){
        let new_contact = new Contact(name, email, tel, address);
        let geoData = await get_geo.getGeoLocation(address);
        if (geoData != null){
            new_contact.addGeoCoordinates(geoData[0],geoData[1],geoData[2]);
            let weatherData = await get_weather.getWeatherData(geoData[0], geoData[1]);
            if (weatherData != null){
                new_contact.addWeatherData(weatherData.temp,weatherData.feels_like,weatherData.humidity);
            }
        } 
        let collection = await _get_contacts_collection();
        collection.insertOne(new_contact, (err, obj) => {
            if (err) throw err;
            console.log('1 Contact was inserted in the database with id -> '+obj.insertedId);
            res.send('Contact correctly inserted in the Database.');
        });
        
    } else {
        console.log('The Contact was not inserted in the database since it is not valid.');
        res.send('Error. User not inserted in the database.');
    }
};

/**
 * A function that lists all contacts with all information that is
 * in the file. 
 * @param {*} req 
 * @param {*} res 
 */
module.exports.list_all = async (req, res) => {
    let collection = await _get_contacts_collection();
    collection.find({}).toArray((err, items)=>{
        if (err) throw err;
        if(items.length == 0){
            console.log('Database is empty');
        }
        console.log(items.length+" item(s) sent.")
        res.send(items);        
    });    
};

/**
 * A function that gets a contact by name and returns all
 * data of the requested contact. 
 * @param {*} req 
 * @param {*} res 
 */
module.exports.get_contact = async (req, res) => {
    let name_to_match = req.params.name;
    let collection = await _get_contacts_collection();
    collection.find({"name": name_to_match}).toArray((err, items)=>{
        if (err) throw err;
        if(items.length > 0) {
            console.log(items.length+' item(s) sent.');
            res.send(items);
        }else{
            console.log('Contact was not found.');
            res.send('There is no user with name '+name_to_match);
        }
    });
        
};

/**
 * A function to update the information about a given contact.
 * @param {*} req 
 * @param {*} res 
 */
module.exports.update_contact = async (req, res) => {
    let name = req.body.name;
    let email = req.body.email;
    let tel = req.body.tel; 
    let address = req.body.address;
    let isValid = await v.validate_fields(name, email, tel, address);
    if (isValid){
        let collection = await _get_contacts_collection();
        let new_vals = {$set: {'name': name, 'email': email, 'tel': tel, 'address': address}};
        collection.updateOne({'name': name}, new_vals, (err, obj) => {
            if (err) throw err;
            console.log("1 document updated");
            res.send('Contact correctly updated.');
        });
    } else {
        console.log("The document was not updated");
        let msg = 'The new user data is not valid.';
        res.send(msg);
    }
};

/**
 * A function that deletes the information about a given contact.
 * @param {*} req 
 * @param {*} res 
 */
module.exports.delete_contact = async (req, res) => {
    let name_to_delete = req.params.name;
    let collection = await _get_contacts_collection();
    collection.deleteOne({'name': name_to_delete}, (err, obj) => {
        if (err) throw err;
        if (obj.result.n > 0){
            console.log("1 document deleted");
            res.send('Contact deleted.');
        } else {
            res.send('Contact was not found.');
        }
    });
};
