$(document).ready(function() {

    $("#btn-find-times").click(function(event) {
        event.preventDefault();
        $(".showfares").hide();
        $(".listtimes").show();
        $("#list-times").empty();

        let id_input = $("#find-times-inp").val();
        let routeid_input = $("#find-timesroute-inp").val();
        let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
        $("#list-times").append(tbl);

        $.ajax({
            url: '/mapsstoptime/' + id_input,
            type: 'GET',
            contentType: 'application/json',
            success: function(response) {
                for (let i = 0; i < response.times.length; i++) {
                    let obj = response.times[i];
                    let tbl_line = '';
                    /**  To add an effect in the table, we can apply
                         even and odd classes. */
                    if (routeid_input === obj.route_id) {
                        if (i % 2 == 0) {
                            tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                        } else {
                            tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                        }
                        $("#table-list").append(tbl_line)
                    }
                }
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText
                alert('Error - ' + errorMessage);
            }
        });
    });


});