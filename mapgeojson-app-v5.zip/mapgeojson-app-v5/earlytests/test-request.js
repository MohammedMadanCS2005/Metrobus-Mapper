var request = require('request');
var myurl = 'http://localhost:3000';



request.post({
    headers: { 'content-type': 'application/json' },
    url: myurl + '/maps',
}, function(error, response, body) {
    if (error) console.log(error);
    console.log(body);
});

request.post({
    headers: { 'content-type': 'application/json' },
    url: myurl + '/mapsroutes',
}, function(error, response, body) {
    if (error) console.log(error);
    console.log(body);
});

request.get({
    headers: { 'content-type': 'application/json' },
    url: myurl + '/maps/100',
}, function(error, response, body) {
    if (error) console.log(error);
    console.log(body);
});

request.get({
    headers: { 'content-type': 'application/json' },
    url: myurl + '/mapsroutes/103',
}, function(error, response, body) {
    if (error) console.log(error);
    console.log(body);
});