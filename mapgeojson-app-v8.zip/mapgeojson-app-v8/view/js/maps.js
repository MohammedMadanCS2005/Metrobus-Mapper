var map = L.map('map').setView([47.560539, -52.712830], 13);
var baseMap = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png?{foo}', { foo: 'bar', attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' });

var baseMaps = {
    "OpenStreetMap": baseMap
};

var layerControl = L.control.layers(baseMaps, {}).addTo(map);
baseMap.addTo(map);


$("#btn-route23").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/23',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/23',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.stop_name + '</h3>');
                    },
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});