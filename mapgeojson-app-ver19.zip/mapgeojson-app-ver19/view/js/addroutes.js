$(document).ready(function() {

    $("#btn-addroutes").click(function(event) {
        event.preventDefault();
        $.ajax({
            url: '/mapsroutes',
            type: 'POST',
            contentType: 'application/json',
            success: function(response) {
                console.log(JSON.stringify(response));
                $("#add-out").text(response);
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText
                alert('Error - ' + errorMessage);
            }
        });
    });


});