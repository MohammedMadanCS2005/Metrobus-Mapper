const express = require('express')
const router = express.Router()
const map_controller = require("../controller/map-controller")

router.post("/", map_controller.create)
router.delete("/:id", map_controller.deleteOne)

module.exports = router